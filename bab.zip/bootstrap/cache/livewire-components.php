<?php return array (
  'book-table' => 'App\\Http\\Livewire\\BookTable',
  'order-table' => 'App\\Http\\Livewire\\OrderTable',
  'table' => 'App\\Http\\Livewire\\Table',
  'user-order-table' => 'App\\Http\\Livewire\\UserOrderTable',
  'user-table' => 'App\\Http\\Livewire\\UserTable',
);