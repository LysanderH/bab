<?php if(session('error')): ?>
    <div class="alert alert-error">
        <p class="alert__text"><?php echo e(session('error')); ?></p>
    </div>
<?php endif; ?>
<?php /**PATH E:\Projekte\2021\bab\resources\views/layout/error.blade.php ENDPATH**/ ?>