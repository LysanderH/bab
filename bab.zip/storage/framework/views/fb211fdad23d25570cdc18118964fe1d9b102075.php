<div>
    <div class="table__sort">
        <form class="search" method="GET">
            <input type="search" name="term" class="search__control form-control" wire:model="term"
                   placeholder="Rechercher">
            <noscript>
                <button role="button" type="submit">Rechercher</button>
            </noscript>
        </form>
        <form class="per-page" method="GET">
            <select name="perPage" class="per-page__control" wire:model="perPage">
                <option value="25">25</option>
                <option value="50">50</option>
                <option value="75">75</option>
                <option value="100">100</option>
            </select>
            <noscript>
                <button role="button" type="submit">Changer</button>
            </noscript>
        </form>
    </div>
    <div class="table__wrapper">
        <table class="table">
            <thead class="table__head">
                <tr class="table__row">
                    <th class="talbe__heading" scope="col">
                        &nbsp;
                    </th>
                    <th class="talbe__heading" scope="col">
                        &nbsp;
                    </th>
                    <th class="talbe__heading" scope="col">
                        <a href="?sortBy=name"
                           class="table__link"
                           wire:click.prevent="sortBy('name')">Nom</a>
                    </th>
                    <th class="talbe__heading" scope="col">
                        <a href="?sortBy=group" class="table__link" wire:click.prevent="sortBy('group')">Groupe</a>
                    </th>
                    <th class="talbe__heading" scope="col">
                        Actions
                    </th>
                </tr>
            </thead>
            <tbody class="table__body" wire:loading.class.delay="loading">
                <?php if(count($users)): ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table__row">
                            <td class="talbe__data"><?php echo e($loop->iteration); ?></td>
                            <td class="talbe__data">
                                <img src="<?php echo e(asset('storage/avatars/small_' . $u->avatar)); ?>" alt="Foto de profil"
                                     width="50"
                                     height="50"
                                     class="profile">
                            </td>
                            <td class="talbe__data"><?php echo e($u->name); ?></td>
                            <td class="talbe__data">
                                <?php echo e($u->group); ?>

                            </td>
                            <td class="table__data table__data--action">
                                <div>
                                    <a href="<?php echo e(route('admin.user.show', ['user' => $u->id])); ?>"
                                       class="table__link table__link--show"><?php echo $__env->make('icons.eye', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><span
                                              class="sr-only">Voir
                                            l’utilisateur</span></a>
                                    <form action="<?php echo e(route('admin.user.destroy', ['user' => $u->id])); ?>"
                                          method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="table__link table__link--delete">
                                            <?php echo $__env->make('icons.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <span class="sr-only">Supprimer
                                                l’utilisateur</span></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr class="table__row">
                        <td class="talbe__data table__data--no-data" colspan="5">
                            Aucun utilisateur existe
                        </td>
                    </tr>
                <?php endif; ?>

            </tbody>
        </table>
    </div>
    <?php echo e($users->links()); ?>

</div>
<?php /**PATH E:\Projekte\2021\bab\resources\views/livewire/user-table.blade.php ENDPATH**/ ?>