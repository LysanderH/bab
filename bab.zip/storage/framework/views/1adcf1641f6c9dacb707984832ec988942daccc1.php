<?php $__env->startSection('content'); ?>
    <header class="header">
        <div class="header__wrapper">
            <h1 class="header__heading">Book a Book <span class="sr-only">- Se connecter</span></h1>
        </div>
    </header>
    <main>
        <form method="POST" action="<?php echo e(route('login')); ?>" class="form">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="email"
                       class="form-label"><?php echo e(__('E-Mail Address')); ?></label>

                <input id="email" type="email"
                       class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                       value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="info@lysander-hans.com"
                       autofocus>

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="password" class="form-label"><?php echo e(__('Mot de passe')); ?></label>

                <input id="password" type="password"
                       class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                       required autocomplete="current-password" placeholder="Mot de passe">
                <span class="form-check__checkbox"></span>

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="remember"
                           id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                    <label class="form-check-label" for="remember">
                        <?php echo e(__('Se souvenir de moi')); ?>

                    </label>
                    <span class="form-check-checkbox"></span>
                </div>
            </div>

            <div class="form-group">
                <button type="submit" class="btn btn-submit">
                    <?php echo e(__('Se connecter')); ?>

                </button>

                <?php if(Route::has('password.request')): ?>
                    <a class="link" href="<?php echo e(route('password.request')); ?>">
                        <?php echo e(__('Vous avez oublié votre mot de passe?')); ?>

                    </a>
                <?php endif; ?>
                <a href="/register" class="link">Je n’ai pas de compte.</a>
            </div>
        </form>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', ['title'=>'Se connecter'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projekte\2021\bab\resources\views/auth/login.blade.php ENDPATH**/ ?>