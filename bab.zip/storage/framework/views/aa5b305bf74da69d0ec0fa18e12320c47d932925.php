<?php $__env->startSection('content'); ?>
    <header class="header">
        <div class="header__wrapper">
            <h1 class="header__heading">Book a Book <span class="sr-only">- Commander partie 2</span>
            </h1>
            <?php if (isset($component)) { $__componentOriginalce5cb24ec15ac7fa62cd06f2e9080b95aa2a6866 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UserMenu::class, []); ?>
<?php $component->withName('user-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalce5cb24ec15ac7fa62cd06f2e9080b95aa2a6866)): ?>
<?php $component = $__componentOriginalce5cb24ec15ac7fa62cd06f2e9080b95aa2a6866; ?>
<?php unset($__componentOriginalce5cb24ec15ac7fa62cd06f2e9080b95aa2a6866); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
    </header>
    <main>
        <?php echo $__env->make('layout.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layout.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('student.order.store')); ?>" method="POST" class="book-form">
            <?php echo csrf_field(); ?>
            <div class="table__wrapper">
                <table class="table">
                    <thead class="table__head">
                        <tr class="table__row">
                            <th class="talbe__heading" scope="col">
                                &nbsp;
                            </th>
                            <th class="talbe__heading" scope="col">
                                &nbsp;
                            </th>
                            <th class="talbe__heading" scope="col">
                                Titre
                            </th>
                            <th class="talbe__heading" scope="col">
                                Prix unitaire
                            </th>
                            <th class="talbe__heading" scope="col">
                                Exemplaires
                            </th>
                            <th class="talbe__heading" scope="col">
                                Prix
                            </th>
                        </tr>
                    </thead>
                    <tbody class="table__body">
                        <?php if(count($books)): ?>
                            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="table__row">
                                    <td class="talbe__data"><?php echo e($loop->iteration); ?></td>
                                    <td class="talbe__data">
                                        <img src="<?php echo e(asset('storage/covers/small_' . $book->cover)); ?>"
                                             alt="Foto de profil"
                                             width="250"
                                             height="250">
                                    </td>
                                    <td class="talbe__data"><?php echo e($book->title); ?></td>
                                    <td class="talbe__data">
                                        <?php echo number_format($book->price, 2, ',', ' ') . '€'; ?>
                                    </td>
                                    <td class="talbe__data talbe__data--action">
                                        <div class="form-group">
                                            <label for="amount<?php echo e($book->id); ?>"
                                                   class="form-label"><?php echo e(__('Examplaires')); ?></label>

                                            <input id="amount<?php echo e($book->id); ?>" type="number"
                                                   class="form-control amount-input <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                   name="amount[<?php echo e($book->id); ?>]"
                                                   value="<?php echo e($amount ?? (old('amount') ?? 1)); ?>" required
                                                   placeholder="0" min="0" data-price="<?php echo e($book->price); ?>"
                                                   data-id="<?php echo e($book->id); ?>">

                                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="invalid-feedback" role="alert">
                                                    <?php echo e($message); ?>

                                                </p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </td>
                                    <td class="talbe__data" id="price-<?php echo e($book->id); ?>">
                                        <?php echo number_format($book->price, 2, ',', ' ') . '€'; ?>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr class="table__row">
                                <td class="talbe__data table__data--no-data" colspan="7">
                                    Aucun livre ajouté
                                </td>
                            </tr>
                        <?php endif; ?>

                    </tbody>
                    <tfoot>
                        <tr class="table__row">
                            <th class="talbe__data table__data--no-data" colspan="5">
                                Total
                            </th>
                            <td class="talbe__data table__data--no-data" colspan="1" id="total">
                                <?php echo number_format($total ?? 0, 2, ',', ' ') . '€'; ?>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <div class="form-group">
                <button type="submit" class="btn btn-submit">
                    <?php echo e(__('Enregistrer la commande')); ?>

                </button>
            </div>
        </form>
    </main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const amountFields = document.querySelectorAll('.amount-input');
        const totalNode = document.querySelector('#total');

        function calculateTotal() {
            let total = 0;
            amountFields.forEach(function(field) {
                total = total + (field.dataset.price * field.value);
                totalNode.innerHTML = new Intl.NumberFormat('fr-FR', {
                    style: 'currency',
                    currency: 'EUR',
                }).format(total);
            });
        }

        function calculateBookTotal(e) {
            let bookTotal = 0;
            const bookTotalNode = document.querySelector('#price-' + e.target.dataset.id);
            bookTotal = bookTotal + (e.target.dataset.price * e.target.value);
            bookTotalNode.innerHTML = new Intl.NumberFormat('fr-FR', {
                style: 'currency',
                currency: 'EUR',
            }).format(bookTotal);
        }

        amountFields.forEach(function(field) {
            field.addEventListener('change', function(e) {
                calculateBookTotal(e);
                return calculateTotal();
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', ['title'=>'Commander'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projekte\2021\bab\resources\views/student/order/create-two.blade.php ENDPATH**/ ?>