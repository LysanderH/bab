<?php $__env->startSection('content'); ?>
    <header class="header">
        <div class="header__wrapper">
            <h1 class="header__heading"><a href="<?php echo e(route('student.dashboard')); ?>" class="header__link">Book a Book</a>
                <span class="sr-only">- Commander</span>
            </h1>
            <?php if (isset($component)) { $__componentOriginalce5cb24ec15ac7fa62cd06f2e9080b95aa2a6866 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UserMenu::class, []); ?>
<?php $component->withName('user-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalce5cb24ec15ac7fa62cd06f2e9080b95aa2a6866)): ?>
<?php $component = $__componentOriginalce5cb24ec15ac7fa62cd06f2e9080b95aa2a6866; ?>
<?php unset($__componentOriginalce5cb24ec15ac7fa62cd06f2e9080b95aa2a6866); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
    </header>
    <main>
        <?php echo $__env->make('layout.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layout.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('student.order.add')); ?>" method="POST" class="book-form">
            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $bacs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul class="bac__list">
                    <li class="bac__item">
                        <p class="bac__name"><?php echo e($bac->name); ?></p>
                        <?php if(count($bac->books)): ?>
                            <ul class="book-list">
                                <?php $__currentLoopData = $bac->books->sortBy('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="book-list__item">
                                        <input type="checkbox" name="book[]" value="<?php echo e($book->id); ?>"
                                               id="book-<?php echo e($book->id); ?>" class="book-card__checkbox"
                                               <?php echo e(in_array($book->id, $selected) ? 'checked' : ''); ?>>
                                        <label for="book-<?php echo e($book->id); ?>" class="book-card__label">
                                            <span class="book-card__heading" role="heading"
                                                  aria-level="2"><?php echo e($book->title); ?>

                                            </span>
                                            <img src="<?php echo e(asset('storage/covers/small_' . $book->cover)); ?>"
                                                 alt="Foto de profil"
                                                 width="250"
                                                 height="250"
                                                 class="book-card__img">
                                            <span class="book-card__price"><?php echo number_format($book->price, 2, ',', ' ') . '€'; ?></span>
                                        </label>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <p>Pas de livres pour ce bac.</p>
                        <?php endif; ?>
                    </li>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group">
                <button type="submit" class="btn btn-submit">
                    <?php echo e(__('Continuer')); ?>

                </button>
            </div>
        </form>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', ['title'=>'Commander'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projekte\2021\bab\resources\views/student/order/create.blade.php ENDPATH**/ ?>