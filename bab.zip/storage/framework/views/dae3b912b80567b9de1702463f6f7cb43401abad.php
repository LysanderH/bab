<?php $__env->startSection('content'); ?>
    <header class="header">
        <div class="header__wrapper">
            <h1 class="header__heading"><a href="<?php echo e(route('admin.dashboard')); ?>" class="header__link">Book a Book</a>
                <span class="sr-only">- Dashboard</span>
            </h1>
            <?php if (isset($component)) { $__componentOriginaldc4150e46bbe41683b27b032b631eb50a1d17205 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminMenu::class, []); ?>
<?php $component->withName('admin-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginaldc4150e46bbe41683b27b032b631eb50a1d17205)): ?>
<?php $component = $__componentOriginaldc4150e46bbe41683b27b032b631eb50a1d17205; ?>
<?php unset($__componentOriginaldc4150e46bbe41683b27b032b631eb50a1d17205); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
    </header>
    <main>
        <?php echo $__env->make('layout.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layout.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <nav class="controls" aria-label="Navigation de la ressource">
            <h2 class="sr-only controls__heading" role="heading" aria-level="2">Navigation du dashboard</h2>
            <div class="controls__wrapper">
                <a href="<?php echo e(route('admin.period.create')); ?>" class="controls__link"><?php echo $__env->make('icons.restart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> Commencer une
                    nouvelle période</a>
                <a href="<?php echo e(route('admin.export')); ?>" class="controls__link"><?php echo $__env->make('icons.export', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> Exporter</a>
            </div>
        </nav>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('table', [])->html();
} elseif ($_instance->childHasBeenRendered('DxPExdS')) {
    $componentId = $_instance->getRenderedChildComponentId('DxPExdS');
    $componentTag = $_instance->getRenderedChildComponentTagName('DxPExdS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('DxPExdS');
} else {
    $response = \Livewire\Livewire::mount('table', []);
    $html = $response->html();
    $_instance->logRenderedChild('DxPExdS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', ['title'=>'Tableau de bord'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projekte\2021\bab\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>