<div>
    <?php if(session()->has('message')): ?>

        <div class="alert alert-success">

            <?php echo e(session('message')); ?>


        </div>

    <?php endif; ?>
    <div class="table__wrapper">
        <table class="table">
            <thead class="table__head">
                <tr class="table__row">
                    <th class="talbe__heading w-50" scope="col">
                        &nbsp;
                    </th>
                    <th class="talbe__heading" scope="col">
                        Nom étudiant
                    </th>
                    <th class="talbe__heading" scope="col">
                        Total
                    </th>
                    <th class="talbe__heading" scope="col">
                        Status
                    </th>
                </tr>
            </thead>
            <tbody class="table__body">
                <?php if(count($orders)): ?>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table__row">
                            <td class="talbe__data"><?php echo e($loop->iteration); ?></td>
                            <td class="talbe__data"><?php echo e($order->user->name); ?></td>
                            <td class="talbe__data"><?php echo number_format($order->total, 2, ',', ' ') . '€'; ?></td>
                            <td
                                class="talbe__data talbe__data--status <?php echo e(transliterator_transliterate('Any-Latin; Latin-ASCII; Lower()', $order->status->name)); ?>">
                                <form action="update/order" class="table__form">
                                    <input type="hidden" value="$order->id">
                                    <select name="status"
                                            wire:change="changeStatus(<?php echo e($order->id); ?>, $event.target.value)"
                                            class=".select">
                                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($status->id); ?>"
                                                    <?php if($status->id === $order->status_id): ?> selected <?php endif; ?>><?php echo e($status->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <noscript>
                                        <button type="submit">Modifier</button>
                                    </noscript>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr class="table__row">
                        <td class="talbe__data table__data--no-data" colspan="4">
                            Aucune commande n'a été faite
                        </td>
                    </tr>
                <?php endif; ?>


            </tbody>
        </table>
    </div>
    <?php echo e($orders->links()); ?>

</div>
<?php /**PATH E:\Projekte\2021\bab\resources\views/livewire/table.blade.php ENDPATH**/ ?>