<nav class="nav" aria-label="Navigation principale">
    <h2 class="sr-only nav__heading" role="heading" aria-level="2">Navigation principale</h2>
    <label for="menu" class="nav__label nav__label--open"><?php echo $__env->make('icons.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><span class="sr-only">Ouvrir le
            menu</span></label>
    <input type="checkbox" id="menu" class="nav__checkbox">
    <div class="nav__wrapper">
        <label for="menu" class="nav__label nav__label--close">><?php echo $__env->make('icons.cross', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><span class="sr-only">Fermer
                le
                menu</span></label>
        <a href="<?php echo e(route('student.dashboard')); ?>" class="nav__link">Dashboard</a>
        <a href="<?php echo e(route('student.order.create')); ?>" class="nav__link">Commander</a>
        <a href="<?php echo e(route('student.order.index')); ?>" class="nav__link">Mes commandes</a>
        <a href="<?php echo e(route('student.profile')); ?>" class="nav__link">Mon compte</a>
        <a href="<?php echo e(route('logout')); ?>"
           onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="nav__link">
            Se déconnecter
        </a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
        </form>
    </div>
</nav>
<?php /**PATH E:\Projekte\2021\bab\resources\views/components/user-menu.blade.php ENDPATH**/ ?>