<?php if(session('success')): ?>
    <div class="alert alert-success">
        <p class="alert__text"><?php echo e(session('success')); ?></p>
    </div>
<?php endif; ?>
<?php /**PATH E:\Projekte\2021\bab\resources\views/layout/success.blade.php ENDPATH**/ ?>