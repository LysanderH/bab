<?php $__env->startSection('content'); ?>
    <header class="header">
        <div class="header__wrapper">
            <h1 class="header__heading"><a href="<?php echo e(route('student.dashboard')); ?>" class="header__link">Book a Book</a>
                <span class="sr-only">- Accueil</span>
            </h1>
            <?php if (isset($component)) { $__componentOriginalce5cb24ec15ac7fa62cd06f2e9080b95aa2a6866 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UserMenu::class, []); ?>
<?php $component->withName('user-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalce5cb24ec15ac7fa62cd06f2e9080b95aa2a6866)): ?>
<?php $component = $__componentOriginalce5cb24ec15ac7fa62cd06f2e9080b95aa2a6866; ?>
<?php unset($__componentOriginalce5cb24ec15ac7fa62cd06f2e9080b95aa2a6866); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
    </header>
    <main>
        <?php echo $__env->make('layout.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layout.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="message__wrapper">
            <?php echo $__env->make('icons.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <p class="message">
                La date limite pour commander des livres est le <b><?php echo e($period->deadline->format('d/m/Y')); ?></b>.
            </p>
        </div>
        <section class="controls" aria-label="Navigation de la ressource">
            <h2 class="sr-only controls__heading" role="heading" aria-level="2">Navigation de la ressource</h2>
            <div class="controls__wrapper">
                <a href="<?php echo e(route('student.order.create')); ?>" class="controls__link">Passer une commande</a>
            </div>
        </section>
        <?php if($order): ?>
            <div class="table__wrapper">
                <table class="table">
                    <thead class="table__head">
                        <tr class="table__row">
                            <th class="talbe__heading" scope="col">
                                &nbsp;
                            </th>
                            <th class="talbe__heading" scope="col">
                                &nbsp;
                            </th>
                            <th class="talbe__heading" scope="col">
                                ISBN
                            </th>
                            <th class="talbe__heading" scope="col">
                                Titre
                            </th>
                            <th class="talbe__heading" scope="col">
                                Auteur
                            </th>
                            <th class="talbe__heading" scope="col">
                                Prix
                            </th>
                        </tr>
                    </thead>
                    <tbody class="table__body" wire:loading.class.delay="loading">
                        <?php if(count($order->books)): ?>
                            <?php $__currentLoopData = $order->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="table__row">
                                    <td class="talbe__data"><?php echo e($loop->iteration); ?></td>
                                    <td class="talbe__data">
                                        <img src="<?php echo e(asset('storage/covers/small_' . $book->cover)); ?>"
                                             alt="Foto de profil"
                                             width="250"
                                             height="250">
                                    </td>
                                    <td class="talbe__data">
                                        <?php echo e($book->ISBN); ?>

                                    </td>
                                    <td class="talbe__data"><?php echo e($book->title); ?></td>
                                    <td class="talbe__data">
                                        <?php echo e($book->author); ?>

                                    </td>
                                    <td class="talbe__data">
                                        <?php echo number_format($book->pivot->current_price, 2, ',', ' ') . '€'; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', ['title'=>'Accueil'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projekte\2021\bab\resources\views/student/dashboard.blade.php ENDPATH**/ ?>