<nav class="nav" aria-label="Navigation principale">
    <h2 class="sr-only nav__heading" role="heading" aria-level="2">Navigation principale</h2>
    <label for="menu" class="nav__label nav__label--open"><?php echo $__env->make('icons.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><span class="sr-only">Ouvrir le
            menu</span></label>
    <input type="checkbox" id="menu" class="nav__checkbox">
    <div class="nav__wrapper">
        <label for="menu" class="nav__label nav__label--close">><?php echo $__env->make('icons.cross', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><span class="sr-only">Fermer
                le
                menu</span></label>
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav__link">Dashboard</a>
        <a href="<?php echo e(route('admin.book.index')); ?>" class="nav__link">Livres</a>
        <a href="<?php echo e(route('admin.user.index')); ?>" class="nav__link">Utilisateurs</a>
        <a href="<?php echo e(route('admin.order.index')); ?>" class="nav__link">Commandes</a>
        <a href="<?php echo e(route('admin.setting.index')); ?>" class="nav__link">Préférences</a>
        <a href="<?php echo e(route('logout')); ?>"
           onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="nav__link">
            Se déconnecter
        </a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
        </form>
    </div>
</nav>
<?php /**PATH E:\Projekte\2021\bab\resources\views/components/admin-menu.blade.php ENDPATH**/ ?>