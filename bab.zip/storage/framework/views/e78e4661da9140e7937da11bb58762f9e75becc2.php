<?php $__env->startSection('content'); ?>
    <header class="header">
        <div class="header__wrapper">
            <h1 class="header__heading"><a href="<?php echo e(route('admin.dashboard')); ?>" class="header__link">Book a Book</a>
                <span class="sr-only">- Préférences</span>
            </h1>
            <?php if (isset($component)) { $__componentOriginaldc4150e46bbe41683b27b032b631eb50a1d17205 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminMenu::class, []); ?>
<?php $component->withName('admin-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginaldc4150e46bbe41683b27b032b631eb50a1d17205)): ?>
<?php $component = $__componentOriginaldc4150e46bbe41683b27b032b631eb50a1d17205; ?>
<?php unset($__componentOriginaldc4150e46bbe41683b27b032b631eb50a1d17205); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
    </header>
    <main>
        <?php echo $__env->make('layout.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layout.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form method="POST" action="<?php echo e(route('admin.setting.update')); ?>" enctype="multipart/form-data"
              class="form">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="account" class="form-label"><?php echo e(__('Compte en banque')); ?></label>

                <input id="account" type="text" class="form-control <?php $__errorArgs = ['account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="account"
                       value="<?php echo e(old('account') ?? ($account->content ?? '')); ?>" required autocomplete="account"
                       placeholder="BE44 7390 0983 0099">

                <?php $__errorArgs = ['account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="invalid-feedback" role="alert">
                        <?php echo e($message); ?>

                    </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-0 form-group">
                <button type="submit" class="btn btn-submit">
                    <?php echo e(__('Enregistrer')); ?>

                </button>
            </div>
        </form>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', ['title'=>'Préférences'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projekte\2021\bab\resources\views/admin/settings/update.blade.php ENDPATH**/ ?>