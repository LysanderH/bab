<?php $__env->startSection('content'); ?>
    <header class="header">
        <div class="header__wrapper">
            <h1 class="header__heading"><a href="<?php echo e(route('admin.dashboard')); ?>" class="header__link">Book a Book</a>
                <span class="sr-only">- Les commandes</span>
            </h1>
            <?php if (isset($component)) { $__componentOriginaldc4150e46bbe41683b27b032b631eb50a1d17205 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminMenu::class, []); ?>
<?php $component->withName('admin-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginaldc4150e46bbe41683b27b032b631eb50a1d17205)): ?>
<?php $component = $__componentOriginaldc4150e46bbe41683b27b032b631eb50a1d17205; ?>
<?php unset($__componentOriginaldc4150e46bbe41683b27b032b631eb50a1d17205); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
    </header>
    <main>
        <?php echo $__env->make('layout.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layout.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section class="controls" aria-label="Navigation de la ressource">
            <h2 class="sr-only controls__heading" role="heading" aria-level="2">Navigation de la ressource</h2>
            <div class="controls__wrapper">
                <a href="<?php echo e(route('admin.order.create')); ?>" class="controls__link"><?php echo $__env->make('icons.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> Ajouter une
                    commande</a>
            </div>
        </section>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order-table', [])->html();
} elseif ($_instance->childHasBeenRendered('wwqoQ0k')) {
    $componentId = $_instance->getRenderedChildComponentId('wwqoQ0k');
    $componentTag = $_instance->getRenderedChildComponentTagName('wwqoQ0k');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wwqoQ0k');
} else {
    $response = \Livewire\Livewire::mount('order-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('wwqoQ0k', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', ['title'=>'Liste des commandes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projekte\2021\bab\resources\views/admin/order/index.blade.php ENDPATH**/ ?>