<div>
    <?php if(session()->has('message')): ?>

        <div class="alert alert-success">

            <?php echo e(session('message')); ?>


        </div>

    <?php endif; ?>
    <div class="table__sort">
        <form class="search" method="GET">
            <input type="search" name="term" class="search__control form-control" wire:model="term"
                   placeholder="Rechercher">
            <noscript>
                <button role="button" type="submit">Rechercher</button>
            </noscript>
        </form>
        <form class="per-page" method="GET">
            <select name="perPage" class="per-page__control" wire:model="perPage">
                <option value="25">25</option>
                <option value="50">50</option>
                <option value="75">75</option>
                <option value="100">100</option>
            </select>
            <noscript>
                <button role="button" type="submit">Afficher</button>
            </noscript>
        </form>
    </div>
    <div class="table__wrapper">
        <table class="table">
            <thead class="table__head">
                <tr class="table__row">
                    <th class="talbe__heading w-50">
                        &nbsp;
                    </th>
                    <th class="talbe__heading" scope="col">
                        Nom
                    </th>
                    <th class="talbe__heading" scope="col">
                        Total
                    </th>
                    <th class="talbe__heading" scope="col">
                        Status
                    </th>
                    <th class="talbe__heading" scope="col">
                        Actions
                    </th>
                </tr>
            </thead>
            <tbody class="table__body" wire:loading.class.delay="loading">
                <?php if(count($orders)): ?>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table__row">
                            <td class="talbe__data"><?php echo e($loop->iteration); ?></td>
                            <td class="talbe__data"><?php echo e($order->user->name); ?></td>
                            <td class="talbe__data">
                                <?php echo number_format($order->total, 2, ',', ' ') . '€'; ?>
                            </td>
                            <td
                                class="talbe__data <?php echo e(transliterator_transliterate('Any-Latin; Latin-ASCII; Lower()', $order->status->name)); ?>">
                                <form action=" update/order" class="table__form form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <input type="hidden" value="<?php echo e($order->id); ?>">
                                    <select name="status"
                                            wire:change="changeStatus(<?php echo e($order->id); ?>, $event.target.value)">
                                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($status->id); ?>"
                                                    <?php if($status->id === $order->status_id): ?> selected <?php endif; ?>><?php echo e($status->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <noscript>
                                        <button type="submit">Modifier</button>
                                    </noscript>
                                </form>
                            </td>
                            <td class="table__data table__data--action">
                                <div>
                                    <a href="<?php echo e(route('admin.order.show', ['order' => $order->id])); ?>"
                                       class="table__link table__link--show"><?php echo $__env->make('icons.eye', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><span
                                              class="sr-only">Voir
                                            la commande</span></a>
                                    <form action="<?php echo e(route('admin.order.destroy', ['order' => $order->id])); ?>"
                                          method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="table__link table__link--delete">
                                            <?php echo $__env->make('icons.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><span
                                                  class="sr-only">Supprimer
                                                la commande</span></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr class="table__row">
                        <td class="talbe__data table__data--no-data" colspan="5">
                            Aucun livre existe
                        </td>
                    </tr>
                <?php endif; ?>

            </tbody>
        </table>
    </div>
    <?php echo e($orders->links('vendor.pagination.default')); ?>

</div>
<?php /**PATH E:\Projekte\2021\bab\resources\views/livewire/order-table.blade.php ENDPATH**/ ?>